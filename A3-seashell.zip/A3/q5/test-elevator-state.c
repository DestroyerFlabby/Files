#include "io_test.h"
#include "elevator-state.h"

// SEASHELL_READONLY

// this is an I/O test client for elevator-state

// look at the simple.in and simple.expect for
// a concrete example of how to use this test client

int main(void) {
  add_void_test("set_position", set_position, 1);
  add_int_test("get_position", get_position, 0);
  add_int_test("get_occupancy", get_occupancy, 0);
  add_void_test("print_position", print_position, 0);
  add_void_test("print_occupancy", print_occupancy, 0);
  add_void_test("enter", enter, 1);
  add_void_test("leave", leave, 1);
  add_void_test("clear", clear, 0);
  add_stop_test("quit");
  io_test();
}
