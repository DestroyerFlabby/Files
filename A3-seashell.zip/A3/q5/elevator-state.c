#include <assert.h>
#include <stdio.h>
#include "elevator-state.h"

///////////////////////////
// INTEGRITY INSTRUCTIONS

// Explicitly state the level of collaboration on this question
// Examples:
//   * I discussed ideas with classmate(s) [include name(s)]
//   * I worked together with classmate(s) in the lab [include name(s)]
//   * Classmate [include name] helped me debug my code
//   * I consulted website [include url]
//   * None
// A "None" indicates you completed this question entirely by yourself
// (or with assistance from course staff)
///////////////////////////
// INTEGRITY STATEMENT:
// I received help from the following sources:

// ERROR_NO_INTEGRITY_STATEMENT

// Name: ERROR_NO_NAME
// login ID: ERROR_NO_LOGIN
///////////////////////////


/////////////////////////////////////////
// BEGIN: DO NOT MODIFY OR CHANGE THIS CODE
// YOU MUST USE THE FOLLOWING CONSTANTS:
const int max_capacity = 15;
const int max_floor = 10;
const int min_floor = 0;
const int initial_occupancy = 0;
const int initial_position = 0;
// END: DO NOT MODIFY OR CHANGE THIS CODE
/////////////////////////////////////////

void set_position(int n) {
  // YOU MUST USE THIS STRING:
  // "WARNING! Invalid Position!\n"
}

int get_position(void) {
  return 0;
}

void print_position(void) {
  // YOU MUST USE THIS STRING:
  // "Position: %d\n"
}

int get_occupancy(void) {
  return 0;
}

void print_occupancy(void) {
  // YOU MUST USE THIS STRING:
  // "Occupancy: %d\n"
}

void enter(int n) {
  // YOU MUST USE THIS STRING:
  // "WARNING! Over Capacity!\n"
}

void leave(int n) {
  // YOU MUST USE THIS STRING:
  // "WARNING! Invalid Leave!\n"
}

void clear(void) {
}
