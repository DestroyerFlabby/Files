// a module for keeping track of the position and occupancy of an elevator

// SEASHELL_READONLY

extern const int max_capacity;
extern const int min_floor;
extern const int max_floor;

// set_position(n) changes the position of the elevator to be n
//   if n < min_floor or n > max_floor, the position does not change
//   and a warning message is displayed
// effects: may change the position to n
//          may display a warning message
void set_position(const int n);

// get_position() returns the current position of the elevator 
int get_position(void);

// print_position() prints the current position of the elevator
// effects: displays a message
void print_position(void);

// get_occupancy() returns the current occupancy of the elevator
int get_occupancy(void);

// print_occupancy() prints the current occupancy of the elevator
// effects: displays a message
void print_occupancy(void);

// enter(n) adds n people to the occupancy of the elevator only if
//   it does not exceed the max_capacity.
//   If adding n people to the occupancy would exceed max_capacity
//   the occupancy does not change and a warning message is displayed.
// effects: may change the occupancy
//          may display a warning message
// example: if max_capacity is 10 and occupancy is 9,
//          enter(2) would not change occupancy and display a warning
void enter(int n);

// leave(n) removes n people from the elevator only if the occupancy
//   is at least n. If n is greater than the occupancy
//   the occupancy does not change and a warning message is displayed.
// effects: may change the occupancy
//          may display a warning message
void leave(int n);

// clear() removes all people from the elevator
// effects: changes the occupancy to 0
void clear(void);
