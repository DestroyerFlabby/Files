#include "readnat.h"
#include "palindrome.h"

// SEASHELL_READONLY

// this is an I/O test client for palindrome

// it continuously reads in Natural numbers and calls palindrome


int main(void) {
  while (1) {
    int n = readnat();
    if (n == -1) {
      break;
    }
    palindrome(n);
  }
}
