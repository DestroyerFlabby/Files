// this is a simple palindrome module

// SEASHELL_READONLY

// palindrome(n) prints out the palindromic number that
//   is n, followed by n reversed.
// example: palindrome(6240) prints out "62400426\n"
// requires: n > 0
// effects: displays a message
void palindrome(int n);
