#include <assert.h>
#include <stdio.h>
#include "rectangle.h"

///////////////////////////
// INTEGRITY INSTRUCTIONS

// Explicitly state the level of collaboration on this question
// Examples:
//   * I discussed ideas with classmate(s) [include name(s)]
//   * I worked together with classmate(s) in the lab [include name(s)]
//   * Classmate [include name] helped me debug my code
//   * I consulted website [include url]
//   * None
// A "None" indicates you completed this question entirely by yourself
// (or with assistance from course staff)
///////////////////////////
// INTEGRITY STATEMENT:
// I received help from the following sources:

// ERROR_NO_INTEGRITY_STATEMENT

// Name: ERROR_NO_NAME
// login ID: ERROR_NO_LOGIN
///////////////////////////


bool point_equal(struct point a, struct point b) {
  return true;
}

bool valid_rectangle(struct rectangle r) {
  return true;
}

bool rectangle_equal(struct rectangle a, struct rectangle b) {
  return true;
}

int rectangle_area(struct rectangle r) {
  return 0;
}

bool rectangle_inside(struct rectangle r, struct point p) {
  return true;
}

struct rectangle rectangle_rotate(struct rectangle r) {
  return r;
}
