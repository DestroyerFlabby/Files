#include <stdbool.h>

// A module for working with rectangles in a Cartesian plane
// where all (x,y) points are on an integer grid

// SEASHELL_READONLY

struct point {
  int x;
  int y;
};

struct rectangle {
  struct point top_left;
  struct point bottom_right;
};

// point_equal(a, b) determines if a and b are the same point
bool point_equal(struct point a, struct point b);

// valid_rectangle(r) determines if r is a valid rectangle
//   with top_left and bottom_right positioned correctly
//   and a non-zero area
bool valid_rectangle(struct rectangle r);

// rectangle_equal(a, b) determines if a and b are the same rectangle
// requires: valid_rectangle(a) and valid_rectangle(b)
bool rectangle_equal(struct rectangle a, struct rectangle b);

// rectangle_area(r) determines the area of rectangle r
// requires: valid_rectangle(r)
int rectangle_area(struct rectangle r);

// rectangle_inside(r, p) determines if point p is inside rectangle r
// note: a point on the edge or corner of a rectangle is inside the rectangle
// requires: valid_rectangle(r)
bool rectangle_inside(struct rectangle r, struct point p);

// rectangle_rotate(r) rotates r 90 degrees clockwise around the origin (0,0)
// hint: the point (x, y) becomes (y, -x) when rotated 90 degrees clockwise
// requires: valid_rectangle(r)
struct rectangle rectangle_rotate(struct rectangle r);
