#include <assert.h>
#include "rectangle.h"

// a simple assertion-based test client for rectangle

// you will probably want to add more tests
// (or create a new test client)

int main(void) {
  struct point p = {0, 0};
  struct rectangle r = {{-1, 1}, {1, -1}};
  struct point outside = {2, 2};
  
  assert(point_equal(p, p));
  assert(valid_rectangle(r));
  assert(rectangle_equal(r, r));
  assert(rectangle_area(r) == 4);
  assert(rectangle_inside(r, p));
  assert(!rectangle_inside(r, outside));
  assert(rectangle_equal(r, rectangle_rotate(r)));
}
