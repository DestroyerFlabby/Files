#include <stdio.h>
#include <assert.h>
#include "log.h"
#include "tolerance.h"
#include "expt.h"

// This is a simple assertion-based test file provided for your testing

// the real test will be the assertion in test_log 
// we can also inspect the results manually (visually) for confirmation

const double test_tolerance = 0.001;

// test_log(n, b) finds log(n,b) and asserts that 
//                b to the power of the result is within test_tolerance of n.
// effects: displays a message for visual testing

void test_log(double n, double b) {
  double result = find_log(n, b, test_tolerance);
  printf("the log of %f base %f is approximately %.3f\n", n, b, result);
  assert(within_tolerance(n, expt(b, result), test_tolerance));
}


int main(void) {
  test_log(9,2.5);
  test_log(5.5,2);
}
