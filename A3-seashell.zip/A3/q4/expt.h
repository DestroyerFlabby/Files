// A module for the expt funciton

// expt(p, k) calculates p to the power of k
double expt(double p, double k);
