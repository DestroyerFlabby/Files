// A module for computing log n WITH base b

// SEASHELL_READONLY

// find_log(double n, double b, double tolerance) determines log n with base b
//   for a given tolerance [see the assignment description]
// requires: n > 0, b > 1 and tolerence > 0
double find_log(double n, double b, double tolerance);
