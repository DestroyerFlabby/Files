#include "readnat.h"
#include "josephus.h"

// SEASHELL_READONLY

// this is an I/O test client for josephus_sequence

// it continuously reads in Natural numbers and calls josephus_sequence


int main(void) {
  while (1) {
    int n = readnat();
    if (n == -1) {
      break;
    }
    josephus_sequence(n);
  }
}
