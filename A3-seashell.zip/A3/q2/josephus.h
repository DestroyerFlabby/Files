// this is a simple Josephus module

// SEASHELL_READONLY

// josephus_sequence(n) prints out J(1), J(2), ..., J(n).
// example: josephus_sequence(10) prints "1, 1, 3, 1, 3, 5, 7, 1, 3, 5.\n"
// requires: n > 0
// effects: displays a sequence
void josephus_sequence(int n);
